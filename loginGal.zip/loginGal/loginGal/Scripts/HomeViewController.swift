//
//  HomeViewController.swift
//  loginGal
//
//  Created by Jorge Elias Blanco Santonja on 28/2/19.
//  Copyright © 2019 Jorge Elias Blanco Santonja. All rights reserved.
//

import Foundation
import Firebase
import FirebaseAuth

class HomeViewController: UIViewController {
    
    @IBOutlet weak var userNameLbl: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
       // let userName = <#value#>
        
        //signInLbl.text = "Sign In"
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    @IBAction func logOutBttn(_ sender: UIButton){
        
        do{
            try Auth.auth().signOut()
            self.performSegue(withIdentifier: "goToLogout", sender: self)
            
        }catch{
            print("Can't log out")
        }
        
    }
    
}
