//
//  HomeViewController.swift
//  loginGal
//
//  Created by Jorge Elias Blanco Santonja on 28/2/19.
//  Copyright © 2019 Jorge Elias Blanco Santonja. All rights reserved.
//

import Foundation
import Firebase
import FirebaseAuth
import FirebaseDatabase
import FirebaseStorage
import SDWebImage

class HomeViewController: UIViewController {
    
    @IBOutlet weak var navigationBarHome: UINavigationBar!
    
    @IBOutlet weak var imageUser: UIImageView!
    
    //To get info of the current user
    let userC = Auth.auth().currentUser?.uid
    //Get the Firebase database
    var ref: DatabaseReference!
    //To handle the database
    var dataBaseHandled: DatabaseHandle?
    
    //TEST 2
    let storageRef = Storage.storage().reference()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        retriveData()
        loadProfileData()
    }
    
    
    func retriveData(){

        ref = Database.database().reference() // 1-Create the database reference
        let userID = Auth.auth().currentUser?.uid // 2-Check the actual user
       
        
        ref.child("Users").child(userID!).observeSingleEvent(of: .value, with: { (snapshot) in
        //Get the user nicKname
        let value = snapshot.value as? NSDictionary
        let username = value?["nickName"] as? String
            
       // print(username!)
        //Show the user nickname
        self.navigationBarHome.topItem?.title = username
        
        })  { (error) in
                print(error.localizedDescription)
            }
    }
    
    func loadProfileData(){
        //if the user is logged in get the profile data
        if let userID = Auth.auth().currentUser?.uid{
            ref.child("Users").child(userID).observe(.value, with: { (snapshot) in
                
                //create a dictionary of users profile data
                let values = snapshot.value as? NSDictionary
                
                //if there is a url image stored in photo
                if let profileImageURL = values?["User_Image"] as? String{
                    //using sd_setImage load photo
                    self.imageUser.sd_setImage(with: URL(string: profileImageURL), placeholderImage: UIImage(named: "User-Image-Profile"))
                
    
                }
                
            })
            
        }//If let
    }//End func

    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    
    
    @IBAction func logOutBttn(_ sender: UIButton){
        
        do{
            try Auth.auth().signOut()
            self.performSegue(withIdentifier: "goToLogout", sender: self)
            
        }catch{
            print("Can't log out")
        }
        
    }
    
    @IBAction func updateProfBttn(_ sender: UIButton) {
        //Go to Update Profile
        self.performSegue(withIdentifier: "goUpdateProfile", sender: self)
    }
    


}
    

