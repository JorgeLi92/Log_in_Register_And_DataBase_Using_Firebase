//
//  UpadteProfile.swift
//  loginGal
//
//  Created by Jorge Elias Blanco Santonja on 12/4/19.
//  Copyright © 2019 Jorge Elias Blanco Santonja. All rights reserved.
//

import UIKit
import Firebase
import SDWebImage

class UpadteProfileView: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    //Textfields
    @IBOutlet weak var nameChanges: UITextField!
    @IBOutlet weak var surnameChanges: UITextField!
    //Image
    @IBOutlet weak var imageChange: UIImageView!
    //an example
    var imageprofile = UIImagePickerController()
    
    //Call the database
    var databaseRef: DatabaseReference!
    //Call Storage
    var storageRef: StorageReference!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //Select the database and storage
        databaseRef = Database.database().reference()
        storageRef = Storage.storage().reference()
        //Show the older data
        loadProfileData()
        
        
    }
    
    //Save the new Data
    @IBAction func saveProfileBttn(_ sender: Any) {
        updateProfileUser()
    }
    
    //Cancel the option of save new data's
    @IBAction func cancelProfileBttn(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    //Select new Photo
    @IBAction func getNewPhoto(_ sender: Any) {
        //Instance of pickerController
        let picker = UIImagePickerController()
        //Set delegate
        picker.delegate = self
        
        //Select the photo libray
        picker.sourceType = .photoLibrary
        //Set media type
        picker.mediaTypes = UIImagePickerController.availableMediaTypes(for: .photoLibrary)!
        //Show new photo
        present(picker, animated: true, completion: nil)
        
        /*How I do it
         
         imageprofile.sourceType = .photoLibrary
         imageprofile.allowsEditing = true
         present(picker, animated: true, completion: nil)
         
         */
        
    }
    
    //Upadteprofile
    func updateProfileUser(){
        //Check if the user is logged in
        if let userUID = Auth.auth().currentUser?.uid{
            //Access point to Firebase Storage
            let storageItems = Storage.storage().reference().child("users_Images/\(userUID)")
            
            //Get new image
            guard let upImage = imageChange.image else{return}
            if let newImage = upImage.pngData(){
                //Upload Image
                storageItems.putData(newImage, metadata: nil, completion: {(metadata, error) in
                    if error != nil{
                        print(error!)
                        return
                    }
                    storageItems.downloadURL(completion: { (url, error) in
                        if error != nil{
                            print(error!)
                            return
                        }
                        if let profPhotoURL = url?.absoluteString{
                            guard let nName = self.nameChanges.text else {return}
                            guard let nSurname = self.surnameChanges.text else {return}
                            
                            let newUploadedProfile =
                                ["Name": nName,
                                 "Surname": nSurname,
                                 "User_Image": profPhotoURL]
                            
                            //Update the firebase for the user
                            self.databaseRef.child("Users").child(userUID).updateChildValues(newUploadedProfile, withCompletionBlock: { (error, reference) in
                                if error != nil{
                                    print(error!)
                                    return
                                }
                                print("Profile Update")
                            })
                            
                        }
                    })
                })
            }
        }
    }
    
    //Show us the old Image
    func loadProfileData(){
        //If the user is logged in the profile
        if let userUID = Auth.auth().currentUser?.uid{
            databaseRef.child("Users").child(userUID).observe(.value, with: { (snapshot) in
                //Create the dictionary for users
                let newValues = snapshot.value as? NSDictionary
                //If there is a url Image stored in photo
                if let profileImageURL = newValues?[""] as? String{
                    self.imageChange.sd_setImage(with: URL(string: profileImageURL), placeholderImage: UIImage(named: "User-Image-Profile"))
                }
                
                self.nameChanges.text = newValues?["Name"] as? String
                self.surnameChanges.text = newValues?["Surname"] as? String
                
            })
        }
        
    }
    
    
    //Back to home
    @IBAction func logOutBttn(_ sender: UIButton) {//Back Home
        self.performSegue(withIdentifier: "backToHome", sender: self)
    }
    
//----------------SELECT IMAGE-------------------------------------
    //Picker Controller
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        
        //Holder variable fot the image choosen
        var newImage = UIImage()
        
        //Save new Image on the variable
        print(info)
        newImage = info[UIImagePickerController.InfoKey.originalImage] as! UIImage
        
        //Update the imageView
        imageChange.image = newImage
        
        //Cancel the selection
        dismiss(animated: true, completion: nil)
    }
    //Cancel ImagePickerController
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
//----------------SELECT IMAGE-------------------------------------
    
    
    
}
