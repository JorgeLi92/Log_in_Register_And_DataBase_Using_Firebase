//
//  ViewController.swift
//  loginGal
//
//  Created by Jorge Elias Blanco Santonja on 25/2/19.
//  Copyright © 2019 Jorge Elias Blanco Santonja. All rights reserved.
//

import UIKit
import Firebase
import FirebaseAuth


class ViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var signInSignUp: UISegmentedControl!
    @IBOutlet weak var signInLbl: UILabel!
    
    
    @IBOutlet weak var emailTxtFld: UITextField!
    @IBOutlet weak var passwordTxtFld: UITextField!
    
    @IBOutlet weak var signInBttn: UIButton!
    //Check if the user is sign in, on the app
    var isSigned = true
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.HideKeyboard()
        // Do any additional setup after loading the view, typically from a nib.
    }
    

    @IBAction func SignInRegisterController(_ sender: UISegmentedControl) {
        //If is not signed, flip to sign view
        isSigned = !isSigned
        
        //Lets change the label up between the segment & email and our Button
        //If the user is registered:
        if isSigned{
            signInLbl.text = "Sign In"
            signInBttn.setTitle("Sign In", for: .normal)
        }else{//If is not
            signInLbl.text = "Register"
            signInBttn.setTitle("Register Now", for: .normal)
            
        }
    }
    
    //Now, lets create the logic to Register & Sign In
    @IBAction func BttnLogIn(_ sender: Any) {//1 - Segment Controll
        //Create 2 constants to email and paswword
        if let eml = emailTxtFld.text, let passw = passwordTxtFld.text{//2
            
            if isSigned{
            //1º - Checking the is the user is registered
            Auth.auth().signIn(withEmail: eml, password: passw, completion: {(user, error) in
                //Check if the textfield isn't null
                if let us = user{
                    self.performSegue(withIdentifier: "goToHome", sender: self)
                }else{
                    //Error: Show message "User password doesn't coincid"
                    //1º Create the UI & message
                    let logUser = UIAlertController(title: "Error Sign in", message: "Password & Email do not match", preferredStyle: .alert)
                    //2º Create action to continue
                    let logAlert = UIAlertAction(title: "OK", style: .default, handler: { (action) in
                        print("Error, the password & email not match")
                    })
                    logUser.addAction(logAlert)
                    self.present(logUser, animated: true, completion: nil)
                 }
                
                })//Authentificator user
            
                
                
                
            }else{//If is not Register
            //Let's register the new user
            Auth.auth().createUser(withEmail: eml, password: passw, completion: {(userAuth, error) in
                //Check if the textfield isn't null
                if let usA = userAuth{
                    self.performSegue(withIdentifier: "goToUserInformation", sender: self)
                }else{
                    //Error: Show message "User already exist"
                    //1º Create the UI and the message that shows
                    let altUser = UIAlertController(title: "Error Register", message: "The user Already Exist", preferredStyle: .alert)
                    //2º Create the action (a button) to continue on the screen and fix the error
                    let actionAlert = UIAlertAction(title: "OK", style: .default, handler: { (action) in
                        print("Error, the user already exist on the DataBase")
                    })
                    altUser.addAction(actionAlert)
                    self.present(altUser, animated: true, completion: nil)
                    
                 }
                })
             }
        
            }//2
    }//1 - Segment Controll
    
    

}
